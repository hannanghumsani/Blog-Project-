import React, { useEffect, useState } from 'react'
import { useLocation } from "react-router-dom";


export default function Blog(props) {
    const location = useLocation();

    console.log(props, " props");
    const data = location.state.data;
    return (
        <>
            <h6>blog Screen</h6>
            <nav className="navbar navbar-light bg-light">
                <span className="navbar-brand mb-0 h1">{data.tittle}</span>
            </nav>
            <br />
            <div dangerouslySetInnerHTML={{ __html: data.content }} />
               

        </>

    );
}
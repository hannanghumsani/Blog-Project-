import React, { useRef, useState } from 'react'
import JoditEditor from "jodit-react";
import { Link } from 'react-router-dom';

const config = {
    buttons: ["bold", "italic", 'underline', 'italic', 'image', 'align'],
};
export default function Newblog() {
    // const navigate = useNavigate();
    const [Value, setValue] = useState("");
    const [name, setName] = useState("");
    const handleSubmit = (event) => {
        // console.log(name);
        event.preventDefault();
    }

    const handleChange = async (event) => {
        const states = {
            tittle: name,
            content: Value
        }
        await fetch('http://localhost:4000/new', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            method: 'POST',
            // We convert the React state to JSON and send it as the POST body
            body: JSON.stringify(states)
        }).then(function (response) {
            console.log(response)
            // navigate("/");
            return response.json();
        });
  

    }
    const editor = useRef(null);
    return (
        <>
            <nav className="navbar navbar-light bg-light">
                <span className="navbar-brand mb-0 h1">New Blog</span>
            </nav>
            <form onSubmit={handleSubmit}>
                <input className="navbar-brand" type="text" placeholder='Tittle' onChange={(e) => setName(e.target.value)} required />
                <JoditEditor ref={editor} onChange={(content) => setValue(content)} config={config} />
                <div className="row">
                    <div className="col-md-6" style={{ margin: "auto", marginTop: "50px" }} >
                        <div style={{ textAlign: "center" }} >
                        </div >
                        <br />
                    </div>
                </div>
                <Link to="/">
                <button type="submit" className="btn btn-secondary" onClick={handleChange}>Submit</button>
                </Link>
            </form>

        </>
    )
}

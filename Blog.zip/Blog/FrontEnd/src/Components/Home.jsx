import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';



const Home = () => {
  const [Data, setData] = useState([]);
  const [state, setState] = useState({ tittle: "", content: "" });

  const fetchData = () => {
    return fetch("http://localhost:4000/get")
      .then((response) => response.json())
      .then((data) => setData(data));
  }
  useEffect(() => {
    fetchData();
  }, [])
  // console.log(Data);

  const handleChange = async (e) => {
    // setState(e.target.value)
    // console.log(e.target.value);
    Data.map((Bobj, index) => {
      if (Bobj._id == e.target.value) {
        state.tittle = Bobj.tittle;
        state.content = Bobj.content;
      }
    })
    console.log(state);
    // await fetch(`http://localhost:4000`, {
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'Accept': 'application/json'
    //   },
    //   method: 'POST',
    //   // We convert the React state to JSON and send it as the POST body
    //   body: JSON.stringify(state)
    // }).then(function (response) {
    //   console.log(response)
    //   // navigate("/");
    //   return response.json();
    // });

  }

  return (
    <>
      <h6>Home Screen</h6>

      <nav className="navbar navbar-light bg-light">
        <span className="navbar-brand mb-0 h1">Eqaim Blogs</span>
      </nav>

      
        {/* <button className='btn btn-light ' >ok </button> */}

        {Data && Data.length > 0 && Data.map((Bobj, index) => (
          // <li key={Bobj.id}>{Bobj.name}</li>
         
          <Link to="/blog" state={{ data: state }}>
             
            <button className='btn btn-light ' value={Bobj._id} onClick={handleChange}>{Bobj.tittle} </button>
          </Link>
         
        ))}
   
      <div className='newblog'>
        <Link to="/new">
          <button className='btn btn-primary '>Write new blog </button>
        </Link>
        </div>
     
    </>
  )
}

export default Home;
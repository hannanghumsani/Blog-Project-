import Home from './Components/Home'
import Newblog from './Components/newblog';
import Blog from "./Components/Blog"

import {
  Route,
  Routes,
  BrowserRouter
} from "react-router-dom";
import {useEffect} from 'react';


function App() {
  return (
    <>

      <BrowserRouter>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/new" element={<Newblog />} />
          <Route path="/blog" element={<Blog />} />
        </Routes>
      </BrowserRouter>

    </>
  );
}
export default App;

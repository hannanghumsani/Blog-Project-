const express = require('express')
const app = express()
const port = 4000
const cors = require('cors');
var bodyParser = require('body-parser');

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));


// const model = require('./model')

// const blog = model.BlogsModels;
const mongoose = require('mongoose');

let run = async () => {

    await mongoose.connect('mongodb://localhost:27017/Contents')
        .then(() => {
            console.log(`CONNECTED `);
        })
        .catch((err) => {
            console.log(` CONNECTION ERROR`);
            console.log(err);
        })


    let blogSchema = new mongoose.Schema({
        tittle: String,
        content: String
    });
    // var blogs = mongoose.model("blogs");
    return BlogsModels = mongoose.model("blogs", blogSchema)
}

let BlogsModels = run();

// module.exports = { BlogsModels };s






app.get('/get', async (req, res) => {
    BlogsModels.find({}, function (err, data) {
        // console.log(err, data, data.length); 
        res.send(data)
    });

})

app.post('/blog', async (req, res) => {

    console.log(req.body);
    // BlogsModels.findOne({_id :req.body}, function (err, data) { 
    //     console.log(err, data, data.length); 
    //     res.send(data)
    // });
})

app.post('/new', async (req, res) => {
    let data = await new BlogsModels(req.body)
    let result = await data.save();
    console.log(result);
    res.send(result)
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})



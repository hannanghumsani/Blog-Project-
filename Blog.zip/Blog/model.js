// const mongoose = require('mongoose');

// let run = async () => {

//     await mongoose.connect('mongodb://localhost:27017/Contents')
//         .then(() => {
//             console.log(`CONNECTED `);
//         })
//         .catch((err) => {
//             console.log(` CONNECTION ERROr`);
//             console.log(err);
//         })


//     let blogSchema = new mongoose.Schema({
//         tittle: String,
//         content: String
//     });
//     return BlogsModels = mongoose.model("blogs", blogSchema)
// }



// let BlogsModels = run();



// module.exports = { BlogsModels };